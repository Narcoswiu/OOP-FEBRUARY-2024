﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.Vehicles.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string str);
    }
}
